import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book';

@Component({
    standalone: true,
  selector: 'app-edit-book',
  imports: [ReactiveFormsModule],
  templateUrl: './edit-book.html',
  styleUrl: './edit-book.css'
})
export class EditBookComponent {
  bookForm!: FormGroup;
  isbn!: string;
   constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private bookService: BookService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.isbn = this.route.snapshot.paramMap.get('isbn')!;
    this.bookForm = this.fb.group({
      title: ['', Validators.required],
      author: ['', Validators.required],
      publicationYear: [null, [Validators.required, Validators.min(1000)]]
    });

    // Fetch the book data and fill the form
    this.bookService.getBook(this.isbn).subscribe({
      next: book => this.bookForm.patchValue(book),
      error: err => alert('Book not found or failed to load')
    });
  }

  onSubmit(): void {
    if (this.bookForm.valid) {
      this.bookService.updateBook(this.isbn, this.bookForm.value).subscribe({
        next: () => {
          alert('Book updated successfully!');
          this.router.navigate(['/books']);
        },
        error: () => alert('Update failed')
      });
    }
  }
}
