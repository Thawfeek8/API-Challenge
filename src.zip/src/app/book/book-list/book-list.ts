import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Book } from '../../models/book';
import { BookService } from '../book';

@Component({
  standalone: true,
  selector: 'app-book-list',
  imports: [CommonModule],
  templateUrl: './book-list.html',
  styleUrl: './book-list.css'
})
export class BookListComponent {

   books: Book[] = [];
  loading: boolean = true;

    constructor(private bookService: BookService) {}
  ngOnInit(): void {
    this.bookService.getAllBooks().subscribe({
      next: (data) => {
        this.books = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading books:', err);
        this.loading = false;
      }
    });
  }

  deleteBook(isbn: string): void {
  if (confirm('Are you sure you want to delete this book?')) {
    this.bookService.deleteBook(isbn).subscribe({
      next: () => {
        alert('Book deleted successfully');
        this.getBooks(); // refresh list
      },
      error: () => alert('Failed to delete book')
    });
  }
}

getBooks(): void {
    this.bookService.getAllBooks().subscribe({
      next: data => this.books = data,
      error: err => console.error('Failed to load books', err)
    });
  }


}
