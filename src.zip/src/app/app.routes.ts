import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login';
import { BookListComponent } from './book/book-list/book-list';
import { AddBookComponent } from './book/add-book/add-book';
import { EditBookComponent } from './book/edit-book/edit-book';

export const routes: Routes = [

    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent},
    { path: 'books', component: BookListComponent},
  { path: 'add-book', component: AddBookComponent},
   { path: 'edit-book/:isbn', component: EditBookComponent }

];
