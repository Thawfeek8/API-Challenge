import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../auth';
import { Router } from '@angular/router';
import { AppUser } from '../../models/user';

@Component({
  standalone:true,
  selector: 'app-login',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class LoginComponent {
  loginForm!: FormGroup;
  errorMsg: string = '';

   constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

   onSubmit(): void {
    if (this.loginForm.invalid) return;


     const user: AppUser = this.loginForm.value;
     this.authService.login(user).subscribe({
      next: (res) => {
        this.authService.saveToken(res.token);
        this.router.navigate(['/books']);
      },
      error: () => {
        this.errorMsg = 'Invalid username or password';
      }
    });
  }

}
