import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppUser } from '../models/user';
import { Observable } from 'rxjs';
import { JwtResponse } from '../models/jwt-response';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
    private readonly authUrl = 'http://localhost:4040/api/auth';

  constructor(private http: HttpClient) {}

  login(user: AppUser): Observable<JwtResponse> {
    return this.http.post<JwtResponse>(`${this.authUrl}/login`, user);
  }

  saveToken(token: string): void {
    localStorage.setItem('jwtToken', token);
  }

  getToken(): string | null {
    return localStorage.getItem('jwtToken');
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  logout(): void {
    localStorage.removeItem('jwtToken');
  }
}
