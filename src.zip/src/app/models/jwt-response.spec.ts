import { JwtResponse } from './jwt-response';

describe('JwtResponse', () => {
  it('should create an instance', () => {
    expect(new JwtResponse()).toBeTruthy();
  });
});
