export class AppUser {
  username!: string;
  password!: string;
}
