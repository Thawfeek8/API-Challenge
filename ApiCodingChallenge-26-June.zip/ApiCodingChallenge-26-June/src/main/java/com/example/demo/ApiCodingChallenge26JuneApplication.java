package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiCodingChallenge26JuneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiCodingChallenge26JuneApplication.class, args);
	}

}
